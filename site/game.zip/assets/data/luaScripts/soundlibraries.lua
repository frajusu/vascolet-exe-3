-- MUSIC --

loadMusic("AFRICA","africa.ogg",0.4);
loadMusic("ANTARTIDA","antartida.ogg",0.4);
loadMusic("AUSTRALIA","australia.ogg",0.4);
loadMusic("BELICE","belice.ogg",0.4);
loadMusic("BRASIL","brasil.ogg",0.4);
loadMusic("CHINA","china.ogg",0.4);
loadMusic("EGIPTO","egipto.ogg",0.4);
loadMusic("EUROPA","europa.ogg",0.4);
loadMusic("MALMARK","malmark.ogg",0.4);
loadMusic("MENU","menu.ogg",0.4);
loadMusic("URUGUAY","uruguay.ogg",0.4);
loadMusic("USA","usa.ogg",0.4);

loadMusic("INTRO","menu.ogg",0.4);
loadMusic("INTRO_MALMARK","intro_malmark.ogg",0.4);
loadMusic("INTRO_GOLEM","golem.ogg",0.4);
loadMusic("INTRO_IGUANA","iguana.ogg",0.4);
loadMusic("INTRO_MOMIA","momia.ogg",0.4);
loadMusic("WIN_V1","menu.ogg",0.4);
loadMusic("WIN_V5","menu.ogg",0.4);
loadMusic("WIN_GAME","win_game.ogg",0.4);
loadMusic("WIN_MALMARK","win_malmark.ogg",0.4);

-- GENERAL FX --

loadEffect("WIN_RACE","win_race.ogg",1.0);
loadEffect("LOSE_RACE","lose_race.ogg",1.0);
loadEffect("ACEITE","aceite_1.ogg",1.0);
loadEffect("ACHIEVEMENT","achievment.ogg",0.5);
loadEffect("CEREAL","cereal.ogg",1.0);
loadEffect("CLICK1","click_1.ogg",1.0);
loadEffect("CLICK2","click_2.ogg",1.0);
loadEffect("COIN1","coin.ogg",1.0);
loadEffect("COIN2","coin2.ogg",1.0);
loadEffect("COIN3","coin3.ogg",1.0);
loadEffect("COIN4","coin4.ogg",1.0);
loadEffect("COMPRA1","compra_1.ogg",1.0);
loadEffect("COMPRA2","compra-2.ogg",1.0);
loadEffect("DERRAPE","derrape.ogg",1.0);
loadEffect("ESTRELLA","estrella.ogg",1.0);
loadEffect("EXTRALIFE","extraLife.ogg",1.0);
loadEffect("LINEARESULTADO","linea_resultado.ogg",1.0);
loadEffect("MISIL1","misil_1.ogg",1.0);
loadEffect("MISIL2","misil_2.ogg",1.0);
loadEffect("NUBENEGRA","nube-negra.ogg",1.0);
loadEffect("PAJAROS1","pajaros_1.ogg",1.0);
loadEffect("PAJAROS2","pajaros_2.ogg",1.0);
loadEffect("PUM1","pum_1.ogg",1.0);
loadEffect("PUM2","pum_2.ogg",1.0);
loadEffect("PUM3","pum_3.ogg",1.0);
loadEffect("SALTO","salto.ogg",1.0);
loadEffect("SEMAFORO_1","semaforo_a.ogg",1.0);
loadEffect("SEMAFORO_2","semaforo_b.ogg",1.0);
-- loadEffect("V1_1","v1_1.ogg",1.0);
-- loadEffect("V1_2","v1_2.ogg",1.0);
-- loadEffect("V1_3","v1_3.ogg",1.0);
-- loadEffect("V1_4","v1_4.ogg",1.0);
-- loadEffect("V1_5","v1_5.ogg",1.0);
-- loadEffect("V1_6","v1_6.ogg",1.0);
-- loadEffect("V5_1","v5_1.ogg",1.0);
-- loadEffect("V5_2","v5_2.ogg",1.0);
-- loadEffect("V5_3","v5_3.ogg",1.0);
-- loadEffect("V5_4","v5_4.ogg",1.0);
-- loadEffect("V5_5","v5_5.ogg",1.0);
-- loadEffect("V5_6","v5_6.ogg",1.0);

loadEffect("V1_1","v1-1-b.ogg",0.4);
loadEffect("V1_2","v1-2-b.ogg",0.4);
loadEffect("V1_3","v1-3-b.ogg",0.4);
loadEffect("V1_4","v1-4-b.ogg",0.4);
loadEffect("V1_5","v1-5-b.ogg",0.4);
loadEffect("V1_6","v1-6-b.ogg",0.4);
loadEffect("V5_1","v5-1-b.ogg",0.4);
loadEffect("V5_2","v5-2-b.ogg",0.4);
loadEffect("V5_3","v5-3-b.ogg",0.4);
loadEffect("V5_4","v5-4-b.ogg",0.4);
loadEffect("V5_5","v5-5-b.ogg",0.4);
loadEffect("V5_6","v5-6-b.ogg",0.4);

loadEffect("V1_TURBO","v1-turbo.ogg",0.7);
loadEffect("V5_TURBO","v5-turbo.ogg",0.7);

loadEffect("BARRO","barro.ogg",1.0);
loadEffect("CHOQUE_BORDE","choque_borde.ogg",1.0);
loadEffect("CORTINA","cortina.ogg",1.0);



