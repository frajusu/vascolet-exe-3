loadImageLibrary("assets/images/coin/","moneda", "moneda");
loadImageLibrary("assets/images/coin/","vaso", "vaso");
loadImageLibrary("assets/images/coin/","bowl", "bowl");
